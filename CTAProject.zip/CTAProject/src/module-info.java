/**
 * 
 */
/**
 * 
 */
module CTAProject {
	
	
		requires java.desktop;
	

}